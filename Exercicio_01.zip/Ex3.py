numero = int(input("Digite um número: "))

for i in range(0, numero+1, 2):
 print(i)