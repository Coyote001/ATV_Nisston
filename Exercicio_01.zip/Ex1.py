nota1 = 10
nota2 = 9
nota3 = 7

media = (nota1 + nota2 + nota3)/3
print(media)